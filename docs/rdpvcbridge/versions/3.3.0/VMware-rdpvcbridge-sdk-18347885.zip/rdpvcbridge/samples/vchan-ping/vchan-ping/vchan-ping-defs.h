/* ********************************************************************************* *
 * Copyright (C) 2011-2021 VMware, Inc.  All rights reserved. -- VMware Confidential *
 * ********************************************************************************* */

/*
 * vchan-ping-defs.h
 *
 * This file contains definitions that are common
 * to both the server and client.
 */

#pragma once

/*
 * The name of our virtual channel
 */
#define VCHAN_NAME "VCPING"

#define SERVER_MESSAGE "Ping"
#define CLIENT_MESSAGE "Pong"
