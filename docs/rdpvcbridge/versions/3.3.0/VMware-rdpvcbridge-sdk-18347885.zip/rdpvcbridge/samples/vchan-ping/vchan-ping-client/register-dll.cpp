/* ********************************************************************************* *
 * Copyright (C) 2011-2021 VMware, Inc.  All rights reserved. -- VMware Confidential *
 * ********************************************************************************* */

/*
 * register-dll.cpp --
 *
 * Adding these two functions, and exporting them through the .def file,
 * allows us to use RegSvr32.exe to register the DLL as an RDP virtual
 * channel client by making the necessary updates to the registry.
 *
 */

#include "stdafx.h"

#define KEY_HIVE HKEY_CURRENT_USER
#define KEY_NAME "Software\\Microsoft\\Terminal Server Client\\Default\\AddIns\\VChanPing"
#define DLL_NAME "vchan-ping-client.dll"
#define REG_ERR_VAL ((HRESULT)0x80040200)


/*
 *----------------------------------------------------------------------
 *
 * Function DllRegisterServer --
 *
 *    Updates the registry to identify the DLL
 *    as an RDP virtual channel client.
 *
 * Results:
 *    Returns S_OK upon success, or an error code
 *    which is displayed by regsvr32
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
HRESULT __stdcall
DllRegisterServer()
{
   /*
    * Start by opening/creating the key
    */
   LONG winErr;
   HKEY hRegKey;
   DWORD keyCreated;
   winErr = ::RegCreateKeyEx(KEY_HIVE,
                             KEY_NAME,
                             0,
                             NULL,
                             REG_OPTION_NON_VOLATILE,
                             KEY_ALL_ACCESS,
                             NULL,
                             &hRegKey,
                             &keyCreated);
   if (winErr != ERROR_SUCCESS) {
      return REG_ERR_VAL+0;
   }


   /*
    * Set the location of the addin in the registry
    */
   HMODULE hMod = ::GetModuleHandle(DLL_NAME);
   if (hMod == NULL) {
      ::RegCloseKey(hRegKey);
      return REG_ERR_VAL+1;
   }

   char appPath[MAX_PATH];
   if (!::GetModuleFileName(hMod, appPath, ARRAYSIZE(appPath))) {
      ::RegCloseKey(hRegKey);
      return REG_ERR_VAL+2;
   }

   const BYTE* data = (const BYTE*)appPath;
   DWORD dataLen = (DWORD)::strlen(appPath)+1;

   winErr = ::RegSetValueEx(hRegKey, "Name", 0, REG_SZ, data, dataLen);
   if (winErr != ERROR_SUCCESS) {
      ::RegCloseKey(hRegKey);
      return REG_ERR_VAL+3;
   }


   /*
    * Mark the addin as View enabled.  If this value doesn't
    * exist or it's set to 0 then View won't load the addin.
    */
   DWORD viewEnabled = 1;

   data = (const BYTE*)&viewEnabled;
   dataLen = sizeof viewEnabled;

   winErr = ::RegSetValueEx(hRegKey, "View Enabled", 0, REG_DWORD, data, dataLen);
   if (winErr != ERROR_SUCCESS) {
      ::RegCloseKey(hRegKey);
      return REG_ERR_VAL+4;
   }

   ::RegCloseKey(hRegKey);
   return S_OK;
}


/*
 *----------------------------------------------------------------------
 *
 * Function DllUnregisterServer --
 *
 *    Removes the registry entries added by DllRegisterServer
 *
 * Results:
 *    Returns S_OK upon success, or an error code
 *    which is displayed by regsvr32
 *
 * Side effects:
 *    None
 *
 *----------------------------------------------------------------------
 */
HRESULT __stdcall
DllUnregisterServer()
{
   if (::RegDeleteKey(KEY_HIVE, KEY_NAME) != ERROR_SUCCESS) {
      return REG_ERR_VAL;
   }

   return S_OK;
}
