/* ********************************************************************************* *
 * Copyright (C) 2011-2021 VMware, Inc.  All rights reserved. -- VMware Confidential *
 * ********************************************************************************* */

/*
 * stdafx.cpp
 */

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
