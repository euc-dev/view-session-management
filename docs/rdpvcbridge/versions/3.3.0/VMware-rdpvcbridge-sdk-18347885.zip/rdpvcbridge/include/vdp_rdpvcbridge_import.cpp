/* ********************************************************************************* *
 * Copyright (C) 2017-2021 VMware, Inc.  All rights reserved. -- VMware Confidential *
 * ********************************************************************************* */

/*
 * vdp_rdpvcbridge_import.cpp
 *
 *    This file is a replacement for the import library vdp_rdpvcbridge.lib
 *    It is completely self contained, just include it in your project.
 *
 *    The difference between this code and the old import library is that if
 *    vdp_rdpvcbridge.dll can not be found all the virtual channel functions will
 *    be passed through to the WTS Windows functions.  This allows programs that
 *    use rdpvcbridge to work on systems where Horizon View is not installed.
 */

#if !defined(WIN32_LEAN_AND_MEAN)
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <tchar.h>

// For GetSystemMetrics()
#pragma comment(lib, "user32.lib")

// For registry functions
#pragma comment(lib, "advapi32.lib")

// For SHGetFolderPath()
#include <Shlobj.h>
#pragma comment(lib, "shell32.lib")

// For the WTS virtual channel functions
#include <wtsapi32.h>
#pragma comment(lib, "wtsapi32.lib")


/*
 * Define function pointer types for all the functions in vdp_rdpvcbridge.dll
 */
typedef BOOL (*tVdpIsViewSession)(
                  DWORD          sessionID);

typedef BOOL (*tVdpIsPCoIPSession)(
                  DWORD          sessionID);

typedef BOOL (*tVdpIsBlastSession)(
                  DWORD          sessionID);

typedef BOOL (*tVdpIsRDPSession)(
                  DWORD          sessionID);

typedef BOOL (*tVdpIsDesktopSession)(
                  DWORD          sessionID);

typedef BOOL (*tVdpIsApplicationSession)(
                  DWORD          sessionID);

typedef BOOL (*tVdpAreVirtualChannelsAvailable)(
                  DWORD          sessionID);

typedef BOOL (*tVdpIsNestedSession)(
                  const DWORD    sessionID,
                  BOOL*          isNestedSession);

typedef BOOL (*tVdpIsNestedClient)(
                  const DWORD    sessionID,
                  BOOL*          isNestedClient);

typedef BOOL (*tVdpGetSDKVersion)(
                  const DWORD    sessionID,
                  PCHAR          localVersionBuffer,
                  const ULONG    localVersionBufferSize,
                  PULONG         pLocalVersionResultStrSize,
                  PULONG         pLocalVersionNum,
                  PCHAR          remoteVersionBuffer,
                  const ULONG    remoteVersionBufferSize,
                  PULONG         pRemoteVersionResultStrSize,
                  PULONG         pRemoteVersionNum);

typedef HANDLE (*tVdpVirtualChannelOpen)(
                  HANDLE         hServer,
                  DWORD          sessionID,
                  LPSTR          pVirtualName);

typedef HANDLE (*tVdpVirtualChannelOpenEx)(
                  DWORD          sessionID,
                  LPSTR          pVirtualName,
                  DWORD          flags);

typedef BOOL (*tVdpVirtualChannelClose)(
                  HANDLE         hChannel);

typedef BOOL (*tVdpVirtualChannelRead)(
                  HANDLE         hChannel,
                  ULONG          timeout,
                  PCHAR          buffer,
                  ULONG          bufferSize,
                  PULONG         pBytesRead);

typedef BOOL (*tVdpVirtualChannelWrite)(
                  HANDLE         hChannel,
                  PCHAR          buffer,
                  ULONG          length,
                  PULONG         pBytesWritten);

typedef BOOL (*tVdpVirtualChannelPurgeInput)(
                  HANDLE         hChannel);

typedef BOOL (*tVdpVirtualChannelPurgeOutput)(
                  HANDLE         hChannel);

typedef BOOL (*tVdpVirtualChannelQuery)(
                  HANDLE            hChannel,
                  WTS_VIRTUAL_CLASS wtsVirtualClass,
                  PVOID*            ppBuffer,
                  DWORD*            pBytesReturned);

typedef BOOL (*tVdpQuerySessionInformationA)(
                  HANDLE         hServer,
                  DWORD          sessionID,
                  WTS_INFO_CLASS wtsInfoClass,
                  LPSTR*         ppBuffer,
                  DWORD*         pBytesReturned);

typedef BOOL (*tVdpQuerySessionInformationW)(
                  HANDLE         hServer,
                  DWORD          sessionID,
                  WTS_INFO_CLASS wtsInfoClass,
                  LPWSTR*        ppBuffer,
                  DWORD*         pBytesReturned);

typedef void (*tVdpFreeMemory)(
                  PVOID          pMemory);

typedef BOOL (*tVdpRegisterSessionNotification)(
                  HWND           hWnd,
                  DWORD          dwFlags);

typedef BOOL (*tVdpUnRegisterSessionNotification)(
                  HWND           hWnd);

typedef int (*tVdpGetSystemMetrics)(
                  int            nIndex);

typedef BOOL (*tVdpLogvMessage)(
                  int            logLevel,
                  const char*    funcName,
                  const char*    format,
                  va_list        args);

/*
 *----------------------------------------------------------------------
 *
 * class Rdpvcbridge
 *
 *----------------------------------------------------------------------
 */
class Rdpvcbridge
{
public:
   Rdpvcbridge();
   ~Rdpvcbridge();

   void  Load();
   void  Unload();
   void  Reset();

   bool  AlreadyLoaded();
   bool  LoadFromSystem32();
   bool  LoadFromRxAgentPath();

   static USHORT GetWtsProtocol(DWORD sessionID);

   HMODULE                             m_hVdpDll;
   tVdpIsViewSession                   m_fVdpIsViewSession;
   tVdpIsPCoIPSession                  m_fVdpIsPCoIPSession;
   tVdpIsBlastSession                  m_fVdpIsBlastSession;
   tVdpIsRDPSession                    m_fVdpIsRDPSession;
   tVdpIsDesktopSession                m_fVdpIsDesktopSession;
   tVdpIsApplicationSession            m_fVdpIsApplicationSession;
   tVdpAreVirtualChannelsAvailable     m_fVdpAreVirtualChannelsAvailable;
   tVdpIsNestedSession                 m_fVdpIsNestedSession;
   tVdpIsNestedClient                  m_fVdpIsNestedClient;
   tVdpGetSDKVersion                   m_fVdpGetSDKVersion;
   tVdpVirtualChannelOpen              m_fVdpVirtualChannelOpen;
   tVdpVirtualChannelOpenEx            m_fVdpVirtualChannelOpenEx;
   tVdpVirtualChannelClose             m_fVdpVirtualChannelClose;
   tVdpVirtualChannelRead              m_fVdpVirtualChannelRead;
   tVdpVirtualChannelWrite             m_fVdpVirtualChannelWrite;
   tVdpVirtualChannelPurgeInput        m_fVdpVirtualChannelPurgeInput;
   tVdpVirtualChannelPurgeOutput       m_fVdpVirtualChannelPurgeOutput;
   tVdpVirtualChannelQuery             m_fVdpVirtualChannelQuery;
   tVdpQuerySessionInformationA        m_fVdpQuerySessionInformationA;
   tVdpQuerySessionInformationW        m_fVdpQuerySessionInformationW;
   tVdpFreeMemory                      m_fVdpFreeMemory;
   tVdpRegisterSessionNotification     m_fVdpRegisterSessionNotification;
   tVdpUnRegisterSessionNotification   m_fVdpUnRegisterSessionNotification;
   tVdpGetSystemMetrics                m_fVdpGetSystemMetrics;
   tVdpLogvMessage                     m_fVdpLogvMessage;
};


/*
 * Create a global instance.
 * This will load vdp_rdpvcbridge.dll when the program loads.
 *
 * With a little effort you can delay load vdp_rdpvcbridge.dll,
 * but then you have to worry about locking during initialization.
 */
static Rdpvcbridge g_rdpvcbridge;


/*
 *----------------------------------------------------------------------
 *
 * Rdpvcbridge::Rdpvcbridge
 *
 *----------------------------------------------------------------------
 */
Rdpvcbridge::Rdpvcbridge()
{
   Reset();
   Load();
}

Rdpvcbridge::~Rdpvcbridge()
{
   Unload();
}


/*
 *----------------------------------------------------------------------
 *
 * Rdpvcbridge::Load
 *
 *    You must use the version of the vdp_rdpvcbridge.dll that ships
 *    with View to ensure compatibility with previous and future
 *    releases of View.  This is why the DLL is no longer provided
 *    as part of the SDK.
 *
 *----------------------------------------------------------------------
 */
void
Rdpvcbridge::Load()
{
   if (m_hVdpDll != NULL) {
      return;
   }

   if (!AlreadyLoaded() &&
       !LoadFromRxAgentPath() &&
       !LoadFromSystem32()) {
      return;
   }

   #define GET_VDP_ADDRESS(fname) \
      m_fVdp##fname = (tVdp##fname)::GetProcAddress(m_hVdpDll, "VDP_" #fname)

   GET_VDP_ADDRESS(IsViewSession);
   GET_VDP_ADDRESS(IsPCoIPSession);
   GET_VDP_ADDRESS(IsBlastSession);
   GET_VDP_ADDRESS(IsRDPSession);
   GET_VDP_ADDRESS(IsDesktopSession);
   GET_VDP_ADDRESS(IsApplicationSession);
   GET_VDP_ADDRESS(AreVirtualChannelsAvailable);
   GET_VDP_ADDRESS(IsNestedSession);
   GET_VDP_ADDRESS(IsNestedClient);
   GET_VDP_ADDRESS(GetSDKVersion);
   GET_VDP_ADDRESS(VirtualChannelOpen);
   GET_VDP_ADDRESS(VirtualChannelOpenEx);
   GET_VDP_ADDRESS(VirtualChannelClose);
   GET_VDP_ADDRESS(VirtualChannelRead);
   GET_VDP_ADDRESS(VirtualChannelWrite);
   GET_VDP_ADDRESS(VirtualChannelPurgeInput);
   GET_VDP_ADDRESS(VirtualChannelPurgeOutput);
   GET_VDP_ADDRESS(VirtualChannelQuery);
   GET_VDP_ADDRESS(QuerySessionInformationA);
   GET_VDP_ADDRESS(QuerySessionInformationW);
   GET_VDP_ADDRESS(FreeMemory);
   GET_VDP_ADDRESS(RegisterSessionNotification);
   GET_VDP_ADDRESS(UnRegisterSessionNotification);
   GET_VDP_ADDRESS(GetSystemMetrics);
   GET_VDP_ADDRESS(LogvMessage);
}


/*
 *----------------------------------------------------------------------
 *
 * Rdpvcbridge::AlreadyLoaded
 *
 *    Check if there is already a copy of vdp_rdpvcbridge.dll loaded.
 *    This can happen if this code is called from the client side.
 *
 *    Note that even in the special case when the agent is also installed,
 *    you must use the version that is already loaded or you will get two
 *    copies of the DLL in memory which will cause problems.
 *
 *----------------------------------------------------------------------
 */
bool
Rdpvcbridge::AlreadyLoaded()
{
   return GetModuleHandleEx(0, _T("vdp_rdpvcbridge.dll"), &m_hVdpDll) != 0;
}


/*
 *----------------------------------------------------------------------
 *
 * Rdpvcbridge::LoadFromSystem32
 *
 *    View currently installs vdp_rdpvcbridge.dll into Windows\System32.
 *
 *    Note: For 32-bit processes running on 64-bit systems, Windows
 *    silently maps Windows\System32 to Windows\SysWOW64 so there's
 *    no need to do a 'is32Bit' test to know which version to load.
 *
 *----------------------------------------------------------------------
 */
bool
Rdpvcbridge::LoadFromSystem32()
{
   /*
    * Look in C:\Windows\System32.  Use SHGetFolderPath() just in case
    * that folder is on another drive.
    */
   TCHAR dllPath[MAX_PATH] = _T(".");
   SHGetFolderPath(NULL, CSIDL_SYSTEM, NULL, SHGFP_TYPE_DEFAULT, dllPath);
   _tcscat_s(dllPath, ARRAYSIZE(dllPath), _T("\\vdp_rdpvcbridge.dll"));

   m_hVdpDll = ::LoadLibrary(dllPath);
   return m_hVdpDll != NULL;
}


/*
 *----------------------------------------------------------------------
 *
 * Rdpvcbridge::LoadFromRxAgentPath
 *
 *    To provide for future compatibility, if View ever decided to put
 *    vdp_rdpvcbridge.dll somewhere other than Windows\System32 then
 *    it will put it with all the other View Agent RX dlls.
 *
 *----------------------------------------------------------------------
 */
bool
Rdpvcbridge::LoadFromRxAgentPath()
{
   /*
    * This is where View places all the Remote Experience (RX) dlls.
    */
   static const HKEY   RX_AGENT_PATH_REG_HIVE = HKEY_LOCAL_MACHINE;
   static const TCHAR* RX_AGENT_PATH_REG_KEY  = _T("Software\\VMware, Inc.")
                                                _T("\\VMware VDM\\RemoteExperienceAgent");
   static const TCHAR* RX_AGENT_PATH_REG_NAME = _T("InstallPath");

   /*
    * Determine if I'm being compiled as 32 or 64 bit.
    * This is normally done with a preprocessor symbol
    * but I don't want this code to depend on such symbols
    * so that it can be easily added to other projects.
    */
   bool is32bit = sizeof(void*) == 4;

   /*
    * You need to look in the registry to find where the
    * dll is installed. For 32-bit appliations make sure
    * to look on non-wow side of the registry.
    */
   HKEY hKey = NULL;
   REGSAM regOpenMode = KEY_QUERY_VALUE
                      | (is32bit ? KEY_WOW64_64KEY : 0);

   LONG err = ::RegOpenKeyEx(RX_AGENT_PATH_REG_HIVE,
                             RX_AGENT_PATH_REG_KEY,
                             0, regOpenMode, &hKey);
   if (err != ERROR_SUCCESS) return false;

   TCHAR dllPath[MAX_PATH];
   DWORD dllPathSz = ARRAYSIZE(dllPath);
   DWORD dllPathType = REG_NONE;

   err = ::RegQueryValueEx(hKey, RX_AGENT_PATH_REG_NAME, NULL,
                           &dllPathType, (LPBYTE)dllPath, &dllPathSz);
   RegCloseKey(hKey);
   if (err != ERROR_SUCCESS) return false;
   if (dllPathType != REG_SZ) return false;

   if (!is32bit) {
      _tcscat_s(dllPath, ARRAYSIZE(dllPath), _T("\\x64"));
   }

   _tcscat_s(dllPath, ARRAYSIZE(dllPath), _T("\\vdp_rdpvcbridge.dll"));

   m_hVdpDll = ::LoadLibrary(dllPath);
   return m_hVdpDll != NULL;
}


/*
 *----------------------------------------------------------------------
 *
 * Rdpvcbridge::Unload
 *
 *----------------------------------------------------------------------
 */
void
Rdpvcbridge::Unload()
{
   if (m_hVdpDll != NULL) {
      ::FreeLibrary(m_hVdpDll);
   }

   Reset();
}


/*
 *----------------------------------------------------------------------
 *
 * Rdpvcbridge::Reset
 *
 *    Clears out all the member variables
 *
 *----------------------------------------------------------------------
 */
void
Rdpvcbridge::Reset()
{
   m_hVdpDll                           = NULL;
   m_fVdpIsViewSession                 = NULL;
   m_fVdpIsPCoIPSession                = NULL;
   m_fVdpIsBlastSession                = NULL;
   m_fVdpIsRDPSession                  = NULL;
   m_fVdpIsDesktopSession              = NULL;
   m_fVdpIsApplicationSession          = NULL;
   m_fVdpAreVirtualChannelsAvailable   = NULL;
   m_fVdpIsNestedSession               = NULL;
   m_fVdpIsNestedClient                = NULL;
   m_fVdpGetSDKVersion                 = NULL;
   m_fVdpVirtualChannelOpen            = NULL;
   m_fVdpVirtualChannelOpenEx          = NULL;
   m_fVdpVirtualChannelClose           = NULL;
   m_fVdpVirtualChannelRead            = NULL;
   m_fVdpVirtualChannelWrite           = NULL;
   m_fVdpVirtualChannelPurgeInput      = NULL;
   m_fVdpVirtualChannelPurgeOutput     = NULL;
   m_fVdpVirtualChannelQuery           = NULL;
   m_fVdpQuerySessionInformationA      = NULL;
   m_fVdpQuerySessionInformationW      = NULL;
   m_fVdpFreeMemory                    = NULL;
   m_fVdpRegisterSessionNotification   = NULL;
   m_fVdpUnRegisterSessionNotification = NULL;
   m_fVdpGetSystemMetrics              = NULL;
   m_fVdpLogvMessage                   = NULL;
}


/*
 *----------------------------------------------------------------------
 *
 * Rdpvcbridge::GetWtsProtocol
 *
 *    Gets the current protocol from WTS for the given session ID
 *
 *----------------------------------------------------------------------
 */
USHORT
Rdpvcbridge::GetWtsProtocol(DWORD sessionID)
{
   LPTSTR pBuffer = NULL;
   DWORD bytesReturned = 0;
   if (!::WTSQuerySessionInformation(WTS_CURRENT_SERVER_HANDLE,
                                     sessionID,
                                     WTSClientProtocolType,
                                     &pBuffer,
                                     &bytesReturned)) {
      return WTS_PROTOCOL_TYPE_CONSOLE;
   }

   if (pBuffer == NULL) {
      return WTS_PROTOCOL_TYPE_CONSOLE;
   }

   USHORT wtsProtocol = *(USHORT*)pBuffer;
   ::WTSFreeMemory(pBuffer);
   return wtsProtocol;
}


/*
 *----------------------------------------------------------------------
 *
 * All the rdpvcbridge API functions pass through these macros.
 *
 * CALL_VDP_FUNCTION
 *    Calls a function in vdp_rdpvcbridge.dll if it's available.
 *
 * CALL_VDP_FUNCTION_OR_CALL_WTS
 *    Calls a function in vdp_rdpvcbridge.dll if it's available.
 *    If it's not available call the corressponding WTS function.
 *
 * CALL_VDP_FUNCTION_OR_RETURN_FALSE
 *    Calls a function in vdp_rdpvcbridge.dll if it's available.
 *    If it's not available return FALSE.
 *
 *----------------------------------------------------------------------
 */
#define CALL_VDP_FUNCTION(fname, ...)                    \
   if (g_rdpvcbridge.m_fVdp##fname != NULL) {            \
      return g_rdpvcbridge.m_fVdp##fname(__VA_ARGS__);   \
   }                                                     \

#define CALL_VDP_FUNCTION_OR_CALL_WTS(fname, ...)        \
   CALL_VDP_FUNCTION(fname, __VA_ARGS__);                \
   return ::WTS##fname(__VA_ARGS__)                      \

#define CALL_VDP_FUNCTION_OR_RETURN_FALSE(fname, ...)    \
   CALL_VDP_FUNCTION(fname, __VA_ARGS__);                \
   return FALSE                                          \


/*
 *----------------------------------------------------------------------
 *
 * VDP_RDPVCBRIDGE_API
 *
 *    Attributes applied to all the API functions
 *
 *----------------------------------------------------------------------
 */
#define VDP_RDPVCBRIDGE_API extern "C"


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_IsViewSession
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_IsViewSession(DWORD sessionID)  // IN
{
   CALL_VDP_FUNCTION_OR_RETURN_FALSE(IsViewSession, sessionID);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_IsPCoIPSession
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_IsPCoIPSession(DWORD sessionID) // IN
{
   CALL_VDP_FUNCTION_OR_RETURN_FALSE(IsPCoIPSession, sessionID);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_IsBlastSession
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_IsBlastSession(DWORD sessionID) // IN
{
   CALL_VDP_FUNCTION_OR_RETURN_FALSE(IsBlastSession, sessionID);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_IsRDPSession
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_IsRDPSession(DWORD sessionID) // IN
{
   CALL_VDP_FUNCTION(IsRDPSession, sessionID);
   return Rdpvcbridge::GetWtsProtocol(sessionID) == WTS_PROTOCOL_TYPE_RDP;
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_IsDesktopSession
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_IsDesktopSession(DWORD sessionID) // IN
{
   CALL_VDP_FUNCTION_OR_RETURN_FALSE(IsDesktopSession, sessionID);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_IsApplicationSession
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_IsApplicationSession(DWORD sessionID) // IN
{
   CALL_VDP_FUNCTION_OR_RETURN_FALSE(IsApplicationSession, sessionID);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_AreVirtualChannelsAvailable
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_AreVirtualChannelsAvailable(DWORD sessionID) // IN
{
   CALL_VDP_FUNCTION_OR_RETURN_FALSE(AreVirtualChannelsAvailable, sessionID);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_IsNestedSession
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_IsNestedSession(const DWORD   sessionID,          // IN
                    BOOL*         pIsNestedSession)   // OUT
{
   CALL_VDP_FUNCTION_OR_RETURN_FALSE(IsNestedSession, sessionID, pIsNestedSession);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_IsNestedClient
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_IsNestedClient(const DWORD   sessionID,        // IN
                   BOOL*         pIsNestedSession) // OUT
{
   CALL_VDP_FUNCTION_OR_RETURN_FALSE(IsNestedClient, sessionID, pIsNestedSession);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_GetSDKVersion
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_GetSDKVersion(const DWORD   sessionID,                   // IN
                  PCHAR         localVersionBuffer,          // IN/OUT
                  const ULONG   localVersionBufferSize,      // IN
                  PULONG        pLocalVersionResultStrSize,  // OUT
                  PULONG        pLocalVersionNum,            // OUT
                  PCHAR         remoteVersionBuffer,         // IN/OUT
                  const ULONG   remoteVersionBufferSize,     // IN
                  PULONG        pRemoteVersionResultStrSize, // OUT
                  PULONG        pRemoteVersionNum)           // OUT
{
   CALL_VDP_FUNCTION_OR_RETURN_FALSE(GetSDKVersion, sessionID,
                                                    localVersionBuffer,
                                                    localVersionBufferSize,
                                                    pLocalVersionResultStrSize,
                                                    pLocalVersionNum,
                                                    remoteVersionBuffer,
                                                    remoteVersionBufferSize,
                                                    pRemoteVersionResultStrSize,
                                                    pRemoteVersionNum);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_VirtualChannelOpen
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API HANDLE
VDP_VirtualChannelOpen(HANDLE hServer,       // IN
                       DWORD  sessionID,     // IN
                       LPSTR  pVirtualName)  // IN
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(VirtualChannelOpen, hServer, sessionID, pVirtualName);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_VirtualChannelOpenEx
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API HANDLE
VDP_VirtualChannelOpenEx(DWORD  sessionID,      // IN
                         LPSTR  pVirtualName,   // IN
                         DWORD  flags)          // IN
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(VirtualChannelOpenEx, sessionID, pVirtualName, flags);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_VirtualChannelClose
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_VirtualChannelClose(HANDLE hChannel)  // IN
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(VirtualChannelClose, hChannel);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_VirtualChannelRead
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_VirtualChannelRead(HANDLE hChannel,      // IN
                       ULONG  timeout,       // IN
                       PCHAR  buffer,        // IN/OUT
                       ULONG  bufferSize,    // IN
                       PULONG pBytesRead)    // OUT
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(VirtualChannelRead, hChannel,
                                                     timeout,
                                                     buffer,
                                                     bufferSize,
                                                     pBytesRead);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_VirtualChannelWrite
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_VirtualChannelWrite(HANDLE hChannel,        // IN
                        PCHAR  buffer,          // IN
                        ULONG  length,          // IN
                        PULONG pBytesWritten)   // OUT
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(VirtualChannelWrite, hChannel,
                                                      buffer,
                                                      length,
                                                      pBytesWritten);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_VirtualChannelPurgeInput
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_VirtualChannelPurgeInput(HANDLE hChannel)   // IN
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(VirtualChannelPurgeInput, hChannel);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_VirtualChannelPurgeOutput
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_VirtualChannelPurgeOutput(HANDLE hChannel)  // IN
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(VirtualChannelPurgeOutput, hChannel);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_VirtualChannelQuery
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_VirtualChannelQuery(HANDLE hChannel,                    // IN
                        WTS_VIRTUAL_CLASS wtsVirtualClass,  // IN
                        PVOID*            ppBuffer,         // OUT
                        DWORD*            pBytesReturned)   // OUT
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(VirtualChannelQuery, hChannel,
                                                      wtsVirtualClass,
                                                      ppBuffer,
                                                      pBytesReturned);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_QuerySessionInformationA
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_QuerySessionInformationA(HANDLE         hServer,        // IN
                             DWORD          sessionID,      // IN
                             WTS_INFO_CLASS wtsInfoClass,   // IN
                             LPSTR*         ppBuffer,       // OUT
                             DWORD*         pBytesReturned) // OUT
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(QuerySessionInformationA, hServer,
                                                           sessionID,
                                                           wtsInfoClass,
                                                           ppBuffer,
                                                           pBytesReturned);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_QuerySessionInformationW
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_QuerySessionInformationW(HANDLE         hServer,        // IN
                             DWORD          sessionID,      // IN
                             WTS_INFO_CLASS wtsInfoClass,   // IN
                             LPWSTR*        ppBuffer,       // OUT
                             DWORD*         pBytesReturned) // OUT
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(QuerySessionInformationW, hServer,
                                                           sessionID,
                                                           wtsInfoClass,
                                                           ppBuffer,
                                                           pBytesReturned);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_FreeMemory
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API void
VDP_FreeMemory(PVOID pMemory)    // IN
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(FreeMemory, pMemory);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_RegisterSessionNotification
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_RegisterSessionNotification(HWND  hWnd,     // IN
                                DWORD dwFlags)  // IN
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(RegisterSessionNotification, hWnd, dwFlags);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_UnRegisterSessionNotification
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_UnRegisterSessionNotification(HWND hWnd)    // IN
{
   CALL_VDP_FUNCTION_OR_CALL_WTS(UnRegisterSessionNotification, hWnd);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_GetSystemMetrics
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API int
VDP_GetSystemMetrics(int nIndex)    // IN
{
   CALL_VDP_FUNCTION(GetSystemMetrics, nIndex);
   return ::GetSystemMetrics(nIndex);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_LogvMessage
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_LogvMessage(int           logLevel,   // IN
                const char*   funcName,   // IN
                const char*   format,     // IN
                va_list       args)       // IN
{
   CALL_VDP_FUNCTION_OR_RETURN_FALSE(LogvMessage, logLevel,
                                                  funcName,
                                                  format,
                                                  args);
}


/*
 *----------------------------------------------------------------------
 *
 * Function VDP_LogMessage
 *
 *----------------------------------------------------------------------
 */
VDP_RDPVCBRIDGE_API BOOL
VDP_LogMessage(int            logLevel,   // IN
               const char*    funcName,   // IN
               const char*    format,     // IN
                              ...)        // IN
{
   va_list args;
   va_start(args, format);

   BOOL logged = VDP_LogvMessage(logLevel,
                                 funcName,
                                 format,
                                 args);
   va_end(args);
   return logged;
}
